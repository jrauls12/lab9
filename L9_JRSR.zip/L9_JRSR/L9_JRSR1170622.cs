﻿using System;

namespace ConsoleApp5
{
    class Program
    {




        static void Main(string[] args)
        {
            Automovil objAutomovil = new Automovil(2019, 10000.00, "", false, 7.50, 0.00);

            Console.WriteLine("ingrese la marca del automovil");
            objAutomovil.DefinirMarca(Console.ReadLine());

            Console.WriteLine("ingrese el precio dle automovil");

            objAutomovil.DefinirPrecio(double.Parse(Console.ReadLine()));

            Console.WriteLine("ingrese el modelo dle automovil");

            objAutomovil.DefinirModelo(int.Parse(Console.ReadLine()));

            Console.WriteLine("ingrese el cambio del dolar");

            objAutomovil.DefinirTipoCambioDolar(double.Parse(Console.ReadLine()));
            Console.WriteLine("ingrese el descuento aplicado");

            objAutomovil.DefinirDescuentoAplicado(double.Parse(Console.ReadLine()));

            //ingresar console write
            //if si la variable

            //poner la demas informacion

            Console.WriteLine(objAutomovil.MostrarInformacion());


            Console.ReadKey();
        }
        class Automovil
        {
            private int modelo;
            private double precio;
            private string marca;
            private bool disponible;
            private double tipoCambioDolar;
            private double descuentoAplicado;
            // metodos publivos:
            public Automovil(int Modelo, double Precio, string Marca, bool Disponible, double TipoCambioDolar, double DescuentoAplicado)
            {
                modelo = Modelo;
                precio = Precio;
                marca = Marca;
                disponible = Disponible;
                TipoCambioDolar = TipoCambioDolar;
                descuentoAplicado = DescuentoAplicado;

            }
            public void DefinirTipoCambioDolar(double unTipoCambioDolar)
            {
                tipoCambioDolar = unTipoCambioDolar;

            }
            public void DefinirDescuentoAplicado(double unDescuentoAplicado)
            {
                descuentoAplicado = unDescuentoAplicado;

            }
            public void DefinirModelo(int unModelo)
            {
                modelo = unModelo;

            }
            public void DefinirPrecio(double unPrecio)
            {
                precio = unPrecio;

            }
            public void DefinirMarca(string unMarca)
            {
                marca = unMarca;

            }
            public void CambiarDisponibilidad()
            {
                if (disponible == true)
                {
                    disponible = false;
                }
                else
                {
                    disponible = true;
                }


            }
            public string MostrarDisponibilidad()
            {
                if (disponible == true)
                {
                    return "disponible";
                }
                else
                {
                    return " no disponible";
                }


            }
            //aqui se muestra todas las variables:
            public string MostrarInformacion()
            {
                return "La marca es :" + marca + ",su precio es de " + precio + ", el modelo es " + modelo + "el tipo de cambio del dolar es en este caso es " + tipoCambioDolar + "y el desucento aplicado es " + descuentoAplicado;
            }

        }
    }
}

